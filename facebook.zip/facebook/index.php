	<?php 
ini_set('user_agent', 
'ngrok-skip-browser-warning');
		include"./header.php";
		include"./content.php";
		include"./footer.php";
		
	?>

	